<html>
<head></head>
<body>
   <form action="addExcel" enctype="multipart/form-data" type="post">
    <div class="row">
       
        <div class="col-md-3">
            <label for="">1</label><br>
            <input type="file" accept="application/msexcel" name="form-file">
            </div>
<!--
        
        
        
    </div>
    
    <div class="row">
       
        <div class="col-md-3">
            <label for="">2</label><br>
            <input type="file" accept="application/msexcel">
            </div>
        
        
        
    </div>
    <div class="row">
       
        <div class="col-md-3">
            <label for="">3</label><br>
            <input type="file" accept="application/msexcel">
            </div>
        
        
        
    </div>
   
    <div class="row">
       
        <div class="col-md-3">
            <label for="">4</label><br>
            <input type="file" accept="application/msexcel">
            </div>
        
        
        
    </div>
    
    <div class="row">
       
        <div class="col-md-3">
            <label for="">5</label><br>
            <input type="file" accept="application/msexcel">
            </div>
        
        
        
    </div>
    
    <div class="row">
       
        <div class="col-md-3">
            <label for="">6</label><br>
            <input type="file" accept="application/msexcel">
            </div>
        
        
        
    </div>
    
    <div class="row">
       
        <div class="col-md-3">
            <label for="">7</label><br>
            <input type="file" accept="application/msexcel">
            </div>
        
-->
     <button type="submit" name="addFile">Submit</button>   
        
    </div>
    </form>
</body>
</html>