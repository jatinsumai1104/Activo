<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card mx-12">
                <div class="card-body p-4">
                    <h1>Request</h1>
                    <form class="form-horizontal" action="getItemData" method="post">
                        <div class="my-cards">
                            <div class="card bg-light mb-3" style="max-width: 18rem;">
                                <div class="card-header">Header</div>
                                <div class="card-body">
                                    <h5 class="card-title">Light card title</h5>
                                    <p class="card-text">Quick sample text to create the card title and make up the body of the card's content.</p>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
