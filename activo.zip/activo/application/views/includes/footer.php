</div><!--END OF app-footer which has been started in left-sidebar.php-->
</div>
    
    <!-- CoreUI and necessary plugins-->
    <script src="../../assets/global/js/jquery.min.js"></script>
    <script src="../../assets/global/js/popper.min.js"></script>
    
    <script src="../../assets/global/js/bootstrap-min.js"></script>
    <script src="../../assets/global/js/pace.min.js"></script>
    <script src="../../assets/global/js/perfect-scrollbar.min.js"></script>
    <script src="../../assets/global/js/coreui.min.js"></script>
    <!-- Plugins and scripts required by this view-->
    <script src="../../assets/vendors/bootstrap-toastr/toastr.min.js"></script>
    <script src="../../assets/global/js/charts.js"></script>
    <script src="../../assets/global/js/custom-tooltips.js"></script>
    <script src="../../assets/vendors/select2/js/select2.full.min.js"></script>
    <script src="../../assets/vendors/datatables/datatables.min.js"></script>
    <script src="../../assets/global/js/main.js"></script>
    <script src="../../assets/vendors/dropzone.js"></script>
    <script src="../../assets/vendors/text-heading/Animated-Type-Heading.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="../../assets/js/custom.js"></script>
    <script src="../../assets/js/manage_request.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body><!--END OF BODY which has been started in header.php-->

</html>

